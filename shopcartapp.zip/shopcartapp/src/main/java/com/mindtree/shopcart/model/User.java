package com.mindtree.shopcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author M1016458
 *
 */
@Entity
public class User implements Comparable<User>{

	/**
	 * emailAddress.
	 */
	@Id
	private String emailId;
	
	/**
	 * password.
	 */
	private String password;
	
	/**
	 * getter method for password..
	 * 
	 * @return password.
	 */
	public String getPassword() {
		return password;
	}
	
	/**
	 * setter method for password.
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * getter method for email Id.
	 * 
	 * @return emailId.
	 */
	public String getEmailId() {
		return emailId;
	}
	
	/**
	 * setter method for email Id.
	 * 
	 * @param emailId
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	/**
	 * Default constructor.
	 */
	public User() {
	}
	
	/**
	 * Parameterized constructor.
	 * 
	 * @param password
	 * @param emailAddress
	 */
	public User(String password, String emailAddress) {
		super();
		this.password = password;
		this.emailId = emailAddress;
	}
	
	
	/**
	 * Hashcode implementation for User class.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	/**
	 * equals method implementation for User class.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	/**
	 * Implementation of compareTo method.
	 */
	@Override
	public int compareTo(User userObj) {
		if (userObj == null) {
			return 1;
		}
		else if (this.emailId == null) {
			return -1;
		}
		else if (userObj.getEmailId() != null && this.getEmailId() != null) {
			return this.getEmailId().compareTo(userObj.getEmailId());
		}
		return 0;
	}
	
}
