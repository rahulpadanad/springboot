package com.mindtree.shopcart.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.shopcart.constants.ShopCartConstants;
import com.mindtree.shopcart.dto.LoginStatusDTO;
import com.mindtree.shopcart.dto.CartDTO;
import com.mindtree.shopcart.exception.ShoppingCartException;
import com.mindtree.shopcart.model.Product;
import com.mindtree.shopcart.model.User;
import com.mindtree.shopcart.serviceImpl.CartServiceImpl;
import com.mindtree.shopcart.serviceImpl.ProductServiceImpl;
import com.mindtree.shopcart.serviceImpl.UserServiceImpl;

/**
 * @author M1016458
 *
 */
@RestController
public class ShoppingCartController {

	/**
	 * LOGGER.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ShoppingCartController.class);
	
	/**
	 * userService.
	 */
	@Autowired
	private UserServiceImpl userService;
	
	/**
	 * cartService.
	 */
	@Autowired
	private CartServiceImpl cartService;
	
	/**
	 * productService.
	 */
	@Autowired
	private ProductServiceImpl productService;
	
	/**
	 * session.
	 */
	private HttpSession session;
	
	@RequestMapping(value=ShopCartConstants.HOME_PAGE_REQ_MAPPING)
	public String homePage() {
		return "Welcome To Shop Cart App";
	}
	
	
	/**
	 * Controller method to process login.
	 * 
	 * @param userEmail
	 * @param password
	 * @param session
	 * @return message
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value=ShopCartConstants.LOGIN_REQ_MAPPING)
	public String login(@RequestParam("userEmail") String userEmail, @RequestParam("password") String password,
			HttpSession session) throws ShoppingCartException {
		
		String message = null;
		LoginStatusDTO loginStatus = userService.checkIfUserExists(userEmail, password);

		if (loginStatus.isLoginSuccess() != null && loginStatus.isLoginSuccess()) {
			saveSession(session, userEmail);
		}
		
		message = loginStatus.getMessage();
		
		LOGGER.info(message);
	
		return message;
	}
	
	/**
	 * Controller method to search products by Id.
	 * 
	 * @param productId
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value=ShopCartConstants.SEARCH_PRODUCT_BY_ID_REQ_MAPPING, method=RequestMethod.GET)
	public Object findProductById(@RequestParam("productId") int productId) throws ShoppingCartException {
		return productService.fetchProductById(productId);
	}
	
	/**
	 * Controller method to search products by name.
	 * 
	 * @param productName
	 * @return List<Product>
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value=ShopCartConstants.SEARCH_PRODUCT_BY_NAME_REQ_MAPPING, method=RequestMethod.GET)
	public List<Product> findProductByName(@RequestParam("productName") String productName) throws ShoppingCartException {
		return productService.fetchProductByName(productName);
	}
	
	/**
	 * Controller method to search products by category.
	 * 
	 * @param productCategory
	 * @return List<Object>
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value=ShopCartConstants.SEARCH_PRODUCT_BY_CATEGORY_REQ_MAPPING, method=RequestMethod.GET)
	public List<Object> findProductByCategory(@RequestParam("productCategory") String productCategory) throws ShoppingCartException {
		
		List<Object> products = null;
		
		if (productCategory.equalsIgnoreCase("Book")) {
			products = productService.fetchAllBooks();
		} 
		else if(productCategory.equalsIgnoreCase("Apparel")) {
			products = productService.fetchAllApparel();
		}
		
		return products;
	}
	
	/**
	 * Controller method to add products to the cart.
	 * 
	 * @param productId
	 * @param quantity
	 * @param request
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value=ShopCartConstants.ADD_TO_CART_REQ_MAPPING, method=RequestMethod.POST)
	public String addProductToCart(@RequestParam("productId") int productId, @RequestParam("quantity") int quantity, HttpServletRequest request) throws ShoppingCartException {
		
		LOGGER.info("Adding Product to cart");
		String message = null;
		String userEmail = (String) session.getAttribute("userEmail");
		
		if (userEmail != null) {
			
			User loggedUser = userService.fetchUserByEmail(userEmail);
			Product product = productService.fetchProductById(productId);
			List<Product> listOfProduct = new ArrayList<Product>();
			
			if (quantity < 0) {
				message = "Please enter valid quantity(greater than 0)";
			}
			
			if (product.getProductQuantity() < quantity) {
				message = "Product is out of stock!";
			}
			
			listOfProduct.add(product);
			
			if (loggedUser != null && !listOfProduct.isEmpty()) {
				boolean savedProd = cartService.addProductToCart(listOfProduct, loggedUser, quantity);
				if (savedProd) {
					productService.updateProductQuantity(product, quantity);
					LOGGER.info("Product added successfully");
					message = "Product has been added to the cart.";
				}
			}
			LOGGER.info("Products not added in the cart");
			message = "Product not added to the cart";
		}
		else {
			LOGGER.info("User session is invalid.");
			message = "User session is invalid. Please login again to continue";
		}
		
		return message;
	}
	
	/**
	 * Controller method to display the cart details.
	 * 
	 * @param userEmail
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value=ShopCartConstants.SHOW_CART_DETAILS_REQ_MAPPING, method = RequestMethod.GET)
	public CartDTO showCartDetails(@RequestParam("userEmail") String userEmail) throws ShoppingCartException {
		CartDTO showDetails = null;
		String email = (String) session.getAttribute("userEmail");
		if (email != null && userEmail.equalsIgnoreCase(email)) {
			LOGGER.info("INFO : showCartDetails");
			showDetails = cartService.viewCart(userEmail);
			if (showDetails != null) {
				return showDetails;
			} else {
				LOGGER.info("Cart is empty");
			}
		}
		LOGGER.info("Kindly login with the same user email to view the cart details");
		return showDetails;
	}
	
	/**
	 * Controller method to remove product by Id.
	 * 
	 * @param productId
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value=ShopCartConstants.REMOVE_PRODUCT_REQ_MAPPING, method = RequestMethod.POST)
	public String removeProductById(@RequestParam("productId") int productId) throws ShoppingCartException {
		
		LOGGER.info("removing product by Id");
		
		boolean successfullyRemoved = false;
		String message = null;
		String userName = (String) session.getAttribute("userEmail");
		Product product = productService.fetchProductById(productId);
		
		if (product != null) {
			successfullyRemoved = cartService.removeProductFromCart(productId, userName);
			if (successfullyRemoved) {
				message =  "Given Product was removed successfully";
			}
		}
		
		if (!successfullyRemoved) {
			message = "Given Product could not be deleted";
		}
		
		LOGGER.info(message);
		
		return message;
	}
	
	/**
	 * Controller method to remove all products from cart.
	 * 
	 * @param email
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value=ShopCartConstants.REMOVE_ALL_PRODUCTS_REQ_MAPPING, method = RequestMethod.POST)
	public String removeAllProductsFromCart(@RequestParam("userEmail") String email) throws ShoppingCartException {
		
		LOGGER.info("removing all products from cart");
		
		String successMessage = null;
		boolean successfullyRemoved = false;
		
		User user = userService.fetchUserByEmail(email);
		
		if (user != null) {
			
			successfullyRemoved = cartService.removeAllProductsFromCart(user.getEmailId());
			
			if (successfullyRemoved) {
				successMessage = "all products removed successfully from cart";
			}
		}
		
		if (!successfullyRemoved) {
			successMessage = "Products could not be deleted";
		}
		
		LOGGER.info(successMessage);
		
		return successMessage;
	}
	
	/**
	 * Save session.
	 * 
	 * @param session
	 * @param userEmail
	 */
	private void saveSession(HttpSession session, String userEmail) {
		session.setAttribute("userEmail", userEmail);
		this.session = session;
	}
}
