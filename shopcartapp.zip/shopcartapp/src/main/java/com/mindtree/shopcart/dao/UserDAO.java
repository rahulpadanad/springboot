package com.mindtree.shopcart.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.shopcart.model.User;

@Transactional
public interface UserDAO extends JpaRepository<User, String>{

}
