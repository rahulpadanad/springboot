package com.mindtree.shopcart.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * Entity class for Book.
 * 
 * @author M1016458
 */
@Entity
@DiscriminatorValue("Book")
public class Book extends Product  {

	/**
	 * genre.
	 */
	private String bookGenre;
	
	/**
	 * author.
	 */
	private String bookAuthor;
	
	/**
	 * publications.
	 */
	private String bookPublications;

	/**
	 * getter method for bookGenre.
	 * 
	 * @return bookGenre.
	 */
	public String getBookGenre() {
		return bookGenre;
	}

	/**
	 * setter method for bookGenre.
	 * 
	 * @param genre
	 */
	public void setBookGenre(String genre) {
		this.bookGenre = genre;
	}

	/**
	 * getter method for bookAuthor.
	 * 
	 * @return bookAuthor
	 */
	public String getBookAuthor() {
		return bookAuthor;
	}

	/**
	 * setter method for bookAuthor.
	 * 
	 * @param author
	 */
	public void setBookAuthor(String author) {
		this.bookAuthor = author;
	}

	/**
	 * getter method for bookPublications.
	 * 
	 * @return bookPulications.
	 */
	public String getBookPublications() {
		return bookPublications;
	}

	/**
	 * setter method for bookPublications.
	 * 
	 * @param publications
	 */
	public void setBookPublications(String publications) {
		this.bookPublications = publications;
	}

	
	/**
	 * Default constructor for Book class.
	 */
	public Book() {
	}
	
	
	/**
	 * Parameterized constructor for Book class.
	 * 
	 * @param productId
	 * @param productName
	 * @param productPrice
	 * @param quantity
	 * @param bookGenre
	 * @param bookAuthor
	 * @param bookPublications
	 */
	public Book(int productId, String productName, double productPrice, int quantity, String bookGenre, String bookAuthor,
			String bookPublications) {
		super(productId, productName, productPrice, quantity);
		this.bookGenre = bookGenre;
		this.bookAuthor = bookAuthor;
		this.bookPublications = bookPublications;
	}
	
	/**
	 * Parameterized constructor for Book class.
	 * 
	 * @param productId
	 * @param productName
	 * @param productPrice
	 */
	public Book(int productId, String productName, float productPrice) {
		super(productId, productName, productPrice);
	}

	/**
	 * Parameterized constructor for Book class.
	 * 
	 * @param productId
	 * @param productName
	 * @param productPrice
	 */
	public Book(int productId, String productName, double productPrice) {
		super(productId, productName, productPrice);
	}


	/**
	 * hashCode implementation for Book class.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((bookAuthor == null) ? 0 : bookAuthor.hashCode());
		result = prime * result + ((bookGenre == null) ? 0 : bookGenre.hashCode());
		result = prime * result + ((bookPublications == null) ? 0 : bookPublications.hashCode());
		return result;
	}


	/**
	 * equals method implementation for Book class.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (bookAuthor == null) {
			if (other.bookAuthor != null)
				return false;
		} else if (!bookAuthor.equals(other.bookAuthor))
			return false;
		if (bookGenre == null) {
			if (other.bookGenre != null)
				return false;
		} else if (!bookGenre.equals(other.bookGenre))
			return false;
		if (bookPublications == null) {
			if (other.bookPublications != null)
				return false;
		} else if (!bookPublications.equals(other.bookPublications))
			return false;
		return true;
	}

	
}
