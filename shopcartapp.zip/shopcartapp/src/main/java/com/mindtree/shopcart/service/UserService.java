package com.mindtree.shopcart.service;

import com.mindtree.shopcart.dto.LoginStatusDTO;
import com.mindtree.shopcart.exception.ShoppingCartException;
import com.mindtree.shopcart.model.User;

public interface UserService {

	public LoginStatusDTO checkIfUserExists(String email, String password) throws ShoppingCartException;
	
	public User fetchUserByEmail(String email) throws ShoppingCartException;
}
