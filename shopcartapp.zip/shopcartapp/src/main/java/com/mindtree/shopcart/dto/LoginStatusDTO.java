package com.mindtree.shopcart.dto;

/**
 * @author M1016458
 *
 */
public class LoginStatusDTO {

	/**
	 * loginSuccess.
	 */
	private Boolean loginSuccess;
	
	/**
	 * newUserCreated.
	 */
	private Boolean newUserCreated;
	
	/**
	 * message.
	 */
	private String message;

	/**
	 * isLoginSuccess method.
	 * 
	 * @return loginSuccess.
	 */
	public Boolean isLoginSuccess() {
		return loginSuccess;
	}

	/**
	 * setLoginSuccess method.
	 * 
	 * @param loginSuccess
	 */
	public void setLoginSuccess(Boolean loginSuccess) {
		this.loginSuccess = loginSuccess;
	}

	/**
	 * isNewUserCreated method.
	 * 
	 * @return newUserCreated.
	 */
	public Boolean isNewUserCreated() {
		return newUserCreated;
	}

	/**
	 * setNewUserCreated method.
	 * 
	 * @param newUserCreated.
	 */
	public void setNewUserCreated(Boolean newUserCreated) {
		this.newUserCreated = newUserCreated;
	}

	/**
	 * getMessage method.
	 * 
	 * @return message.
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * setMessage method.
	 * 
	 * @param message.
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
