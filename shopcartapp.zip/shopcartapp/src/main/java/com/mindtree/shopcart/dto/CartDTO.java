package com.mindtree.shopcart.dto;

import java.util.List;

import com.mindtree.shopcart.model.Product;

public class CartDTO {

	/**
	 * products.
	 */
	private List<Product> products;
	
	/**
	 * userEmailId.
	 */
	private String userEmailId;
	
	/**
	 * cartAmount.
	 */
	private double cartAmount;

	public List<Product> getProducts() {
		return products;
	}
	
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	public String getUserEmailId() {
		return userEmailId;
	}
	
	public void setUserEmailId(String userEmail) {
		this.userEmailId = userEmail;
	}
	
	public double getCartAmount() {
		return cartAmount;
	}
	
	public void setCartAmount(double totalAmountDue) {
		this.cartAmount = totalAmountDue;
	}
	
	
}
