package com.mindtree.shopcart.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * Entity class for Apparel.
 * 
 * @author M1016458
 */
@Entity
@DiscriminatorValue("APPAREL")
public class Apparel extends Product {

	/**
	 * apparelType.
	 */
	private String apparelType;
	
	/**
	 * brand.
	 */
	private String apparelBrand;
	
	/**
	 * design.
	 */
	private String apparelDesign;
	
	
	/**
	 * getter method for apparelType.
	 * 
	 * @return apparelType
	 */
	public String getApparelType() {
		return apparelType;
	}

	/**
	 * setter method for apparelType.
	 * 
	 * @param type
	 */
	public void setApparelType(String type) {
		this.apparelType = type;
	}

	/**
	 * getter method for apparelBrand.
	 * 
	 * @return apparelBrand
	 */
	public String getApparelBrand() {
		return apparelBrand;
	}

	/**
	 * setter method for apparelBrand.
	 * 
	 * @param brand
	 */
	public void setApparelBrand(String brand) {
		this.apparelBrand = brand;
	}

	/**
	 * getter method for apparelDesign.
	 * 
	 * @return apparelDesign.
	 */
	public String getApparelDesign() {
		return apparelDesign;
	}

	/**
	 * setter method for apparelDesign.
	 * 
	 * @param design
	 */
	public void setApparelDesign(String design) {
		this.apparelDesign = design;
	}
	
	/**
	 * Default constructor for Apparel class.
	 */
	public Apparel() {
	}

	/**
	 * Parameterized constructor for Apparel class.
	 * 
	 * @param productId
	 * @param productName
	 * @param productPrice
	 * @param quantity
	 * @param apparelType
	 * @param apparelBrand
	 * @param apparelDesign
	 */
	public Apparel(int productId, String productName, double productPrice,int quantity, String apparelType, String apparelBrand,
			String apparelDesign) {
		super(productId, productName, productPrice, quantity);
		this.apparelType = apparelType;
		this.apparelBrand = apparelBrand;
		this.apparelDesign = apparelDesign;
	}
	
	/**
	 * Parameterized constructor for Apparel class.
	 * 
	 * @param productId
	 * @param productName
	 * @param productPrice
	 */
	public Apparel(int productId, String productName, float productPrice) {
		super(productId, productName, productPrice);
	}

	/**
	 * hashCode implementation for Apparel class.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((apparelBrand == null) ? 0 : apparelBrand.hashCode());
		result = prime * result + ((apparelDesign == null) ? 0 : apparelDesign.hashCode());
		result = prime * result + ((apparelType == null) ? 0 : apparelType.hashCode());
		return result;
	}
	
	/**
	 * equals method implementation for Apparel class.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apparel other = (Apparel) obj;
		if (apparelBrand == null) {
			if (other.apparelBrand != null)
				return false;
		} else if (!apparelBrand.equals(other.apparelBrand))
			return false;
		if (apparelDesign == null) {
			if (other.apparelDesign != null)
				return false;
		} else if (!apparelDesign.equals(other.apparelDesign))
			return false;
		if (apparelType == null) {
			if (other.apparelType != null)
				return false;
		} else if (!apparelType.equals(other.apparelType))
			return false;
		return true;
	}

}
