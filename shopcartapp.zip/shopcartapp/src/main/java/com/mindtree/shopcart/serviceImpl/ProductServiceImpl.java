package com.mindtree.shopcart.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.shopcart.dao.ApparelDAO;
import com.mindtree.shopcart.dao.BookDAO;
import com.mindtree.shopcart.dao.ProductDAO;
import com.mindtree.shopcart.exception.ShoppingCartException;
import com.mindtree.shopcart.model.Apparel;
import com.mindtree.shopcart.model.Book;
import com.mindtree.shopcart.model.Product;
import com.mindtree.shopcart.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	/**
	 * LOGGER.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductServiceImpl.class);
	
	/**
	 * productDAO.
	 */
	@Autowired
	private ProductDAO productDAO;
	
	/**
	 * apparelDAO.
	 */
	@Autowired
	private ApparelDAO apparelDAO;
	
	/**
	 * bookDAO.
	 */
	@Autowired
	private BookDAO bookDAO;

	
	@Override
	public void updateProductQuantity(Product product, int quantity) throws ShoppingCartException {
		LOGGER.info("update product quantity");
		try {
			productDAO.updateQuantity(product.getProductId(), product.getProductQuantity() - quantity);
		} catch (Exception ex) {
			LOGGER.error("Quantity could not be updated");
			throw new ShoppingCartException("Quantity could not be updated");
		}
	}
	
	@Override
	public Product fetchProductById(int productId) throws ShoppingCartException {
		LOGGER.info("Fetch product by id :" + productId);
		Product product = null;
		try {
			Optional<Product> prod = productDAO.findById(productId);
			if (prod != null && prod.get() != null) {
				product = prod.get();
			}
		} catch (Exception ex) {
			LOGGER.error("ERROR : Product not found in database");
			throw new ShoppingCartException("Product not found in database");
		}
		
		return product;
	}

	@Override
	public List<Product> fetchProductByName(String productName) throws ShoppingCartException {
		LOGGER.info("Fetch product by name :" + productName);
		List<Product> prod = null;
		
		try {
			prod = productDAO.findByProductName(productName);
		} catch (Exception ex) {
			LOGGER.error("Product not found in database");
			throw new ShoppingCartException("Product not found in database");
		}
		
		return prod;
	}
	
	@Override
	public List<Object> fetchAllApparel() throws ShoppingCartException{
		LOGGER.info("retrieve details of all apparels");
		List<Object> listOfApparels = new ArrayList<Object>();
		try {
			Iterable<Apparel> apparelIterable = apparelDAO.findAll();
			for (Apparel apparel : apparelIterable) {
				listOfApparels.add(apparel);
			}
		}
		catch (Exception ex) {
			LOGGER.error("Unable to retrieve the Apparels");
			throw new ShoppingCartException("Unable to retrieve the Apparels");
		}
		return listOfApparels;
	}
	
	/**
	 * fetchDataForBooks.
	 * @return listOfBooks
	 * @throws ShoppingCartException 
	 */
	@Override
	public List<Object> fetchAllBooks() throws ShoppingCartException {
		LOGGER.info("retrieve details of all Books");
		List<Object> listOfBooks = new ArrayList<Object>();
		try {
			Iterable<Book> bookIterable = bookDAO.findAll();
			for (Book book : bookIterable) {
				listOfBooks.add(book);
			}
		} catch (Exception ex) {
			LOGGER.error("Unable to retrieve the books");
			throw new ShoppingCartException("Unable to fetch Books from database");
		}
		return listOfBooks;
	}
	
}
