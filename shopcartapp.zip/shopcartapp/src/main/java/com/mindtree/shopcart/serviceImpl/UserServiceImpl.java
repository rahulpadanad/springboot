package com.mindtree.shopcart.serviceImpl;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.shopcart.dao.UserDAO;
import com.mindtree.shopcart.dto.LoginStatusDTO;
import com.mindtree.shopcart.exception.ShoppingCartException;
import com.mindtree.shopcart.model.User;
import com.mindtree.shopcart.service.UserService;

/**
 * 
 * 
 * @author M1016458
 */
@Service
public class UserServiceImpl implements UserService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
	
	/**
	 * userDao.
	 */
	@Autowired
	private UserDAO userDao;
	
	@Override
	public LoginStatusDTO checkIfUserExists(String email, String password) throws ShoppingCartException {
		LOGGER.info("inside checkIfUserAlreadyPresent() method");
		
		LoginStatusDTO loginStatus = new LoginStatusDTO();
		
		try {
			Optional<User> optional = userDao.findById(email);
			if (optional.isPresent() && optional.get().getPassword().equalsIgnoreCase(password)) {
				loginStatus.setLoginSuccess(true);
				loginStatus.setMessage("User logged in successfully.");
			} 
			else if (!optional.isPresent()) {
				userDao.save(new User(password, email));
				loginStatus.setNewUserCreated(true);
				loginStatus.setMessage("New user created. Kindly login again to continue.");
			}
			else {
				loginStatus.setMessage("login credentials are incorrect.");
			}
		} 
		catch (Exception ex) {
			LOGGER.error("Unable to fetch the user : " + email);
			throw new ShoppingCartException("Unable to fetch the user");
		}
		
		return loginStatus;
	}
	
	@Override
	public User fetchUserByEmail(String email) throws ShoppingCartException {
		LOGGER.info("retrieve user by email : " + email);
		try {
			Optional<User> userFromDB = userDao.findById(email);
			if (userFromDB != null && userFromDB.get() != null) {
				return userFromDB.get();
			}
		}
		catch (Exception ex) {
			LOGGER.error("User not present in database" + ex);
			throw new ShoppingCartException("Invalid User");
		}
		return null;
	}
}
