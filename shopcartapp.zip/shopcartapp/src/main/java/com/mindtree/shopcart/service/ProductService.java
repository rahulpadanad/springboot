package com.mindtree.shopcart.service;

import java.util.List;

import com.mindtree.shopcart.exception.ShoppingCartException;
import com.mindtree.shopcart.model.Product;

public interface ProductService {

	/**
	 * @param productId
	 * @return
	 * @throws ShoppingCartException
	 */
	public Product fetchProductById(int productId) throws ShoppingCartException;
	
	/**
	 * @param productName
	 * @return
	 * @throws ShoppingCartException
	 */
	public List<Product> fetchProductByName(String productName) throws ShoppingCartException;
	
	/**
	 * @param product
	 * @param quantity
	 * @throws ShoppingCartException
	 */
	public void updateProductQuantity(Product product, int quantity) throws ShoppingCartException;
	
	/**
	 * @return
	 * @throws ShoppingCartException
	 */
	public List<Object> fetchAllBooks() throws ShoppingCartException;
	
	/**
	 * @return
	 * @throws ShoppingCartException
	 */
	public List<Object> fetchAllApparel() throws ShoppingCartException;
}
