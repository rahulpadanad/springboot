package com.mindtree.shopcart.exception;

public class ShoppingCartException extends Exception {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 1L;

	public ShoppingCartException(String expMessage) {
		super(expMessage);
	}
	
}
