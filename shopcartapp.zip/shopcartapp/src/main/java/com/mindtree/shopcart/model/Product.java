package com.mindtree.shopcart.model;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

/**
 * Entity class representing Product.
 * 
 * @author M1016458
 */
@Entity
@DiscriminatorColumn(name="PRODUCT_CATEGORY", discriminatorType=DiscriminatorType.STRING)
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public class Product implements Comparable<Product>{

	/**
	 * productId.
	 */
	@Id
	private int productId;
	
	/**
	 * productName.
	 */
	private String productName;
	
	/**
	 * productPrice.
	 */
	private double productPrice;
	
	/**
	 * productQuantity.
	 */
	private int productQuantity;
	
	/**
	 * getter method for productId.
	 * 
	 * @return productId.
	 */
	public int getProductId() {
		return productId;
	}

	/**
	 * setter method for productId.
	 * 
	 * @param id
	 */
	public void setProductId(int id) {
		this.productId = id;
	}

	/**
	 * getter method for productName.
	 * 
	 * @return productName.
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * setter method for productName.
	 * 
	 * @param name
	 */
	public void setProductName(String name) {
		this.productName = name;
	}

	/**
	 * getter method for productPrice.
	 * 
	 * @return productPrice.
	 */
	public double getProductPrice() {
		return productPrice;
	}

	/**
	 * setter method for producPrice.
	 * 
	 * @param price.
	 */
	public void setProductPrice(double price) {
		this.productPrice = price;
	}

	/**
	 * getter method for ProductQuantity.
	 * 
	 * @return productQuantity.
	 */
	public int getProductQuantity() {
		return productQuantity;
	}

	/**
	 * setter method for productQuantity.
	 * 
	 * @param quantity
	 */
	public void setProductQuantity(int quantity) {
		this.productQuantity = quantity;
	}
	
	/**
	 * Default constructor for Product class.
	 */
	public Product() {
	}

	/**
	 * Parameterized constructor for Product class.
	 * 
	 * @param productId
	 * @param productName
	 * @param productPrice
	 */
	public Product(int productId, String productName, double productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}

	/**
	 * Parameterized constructor for Product class.
	 * 
	 * @param productId
	 * @param productName
	 * @param productPrice
	 * @param quantity
	 */
	public Product(int productId, String productName, double productPrice, int quantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productQuantity = quantity;
	}

	

	/**
	 * hashCode implementation for Product class.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + productId;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(productPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + productQuantity;
		return result;
	}

	/**
	 * equals method implementation for Product class.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (productId != other.productId)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (Double.doubleToLongBits(productPrice) != Double.doubleToLongBits(other.productPrice))
			return false;
		if (productQuantity != other.productQuantity)
			return false;
		return true;
	}

	/**
	 * Implementation of compareTo method based on comparison of product price.
	 */
	@Override
	public int compareTo(Product prod) {
		if (prod == null) {
			return 1;
		}
		if (this.productPrice > prod.productPrice) {
			return 1;
		} 
		else if (this.productPrice < prod.productPrice) {
			return -1;
		}
		return 0;
	}

}
