package com.mindtree.shopcart.constants;

/**
 * Shopping Cart application constants.
 * 
 * @author M1016458
 */
public class ShopCartConstants {

	/**
	 * HOME_PAGE_REQ_MAPPING.
	 */
	public static final String HOME_PAGE_REQ_MAPPING = "/shoppingcart";
	
	/**
	 * LOGIN_REQ_MAPPING.
	 */
	public static final String LOGIN_REQ_MAPPING = "shoppingcart/login";
	
	/**
	 * REMOVE_PRODUCT_REQ_MAPPING.
	 */
	public static final String REMOVE_PRODUCT_REQ_MAPPING = "/shoppingcart/removeProduct";
	
	/**
	 * REMOVE_ALL_PRODUCTS_REQ_MAPPING.
	 */
	public static final String REMOVE_ALL_PRODUCTS_REQ_MAPPING = "/shoppingcart/removeAllProducts";
	
	/**
	 * SHOW_CART_DETAILS_REQ_MAPPING.
	 */
	public static final String SHOW_CART_DETAILS_REQ_MAPPING = "/shoppingcart/showCartDetails";
	
	/**
	 * ADD_TO_CART_REQ_MAPPING.
	 */
	public static final String ADD_TO_CART_REQ_MAPPING = "/shoppingcart/addToCart";
	
	/**
	 * SEARCH_PRODUCT_BY_ID_REQ_MAPPING.
	 */
	public static final String SEARCH_PRODUCT_BY_ID_REQ_MAPPING = "shoppingcart/search/searchProductById";
	
	/**
	 * SEARCH_PRODUCT_BY_NAME_REQ_MAPPING.
	 */
	public static final String SEARCH_PRODUCT_BY_NAME_REQ_MAPPING = "shoppingcart/search/searchProductByName";
	
	/**
	 * SEARCH_PRODUCT_BY_CATEGORY_REQ_MAPPING.
	 */
	public static final String SEARCH_PRODUCT_BY_CATEGORY_REQ_MAPPING = "shoppingCart/search/searchProductByCategory";
	
}
