package com.mindtree.shopcart.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Entity class for Cart.
 * 
 * @author M1016458
 */
@Entity
@Table(name="cart")
public class Cart implements Comparable<Cart>{
	/**
	 * cartId.
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cartId;
	
	/**
	 * productId.
	 */
	@OneToMany(cascade=CascadeType.ALL)
	private List<Product> products;
	
	/**
	 * totalPrice.
	 */
	private double totalPrice;
	
	/**
	 * user.
	 */
	@OneToOne
	private User user;


	/**
	 * getter method for cardId.
	 * 
	 * @return cartId.
	 */
	public int getCartId() {
		return cartId;
	}


	/**
	 * setter method for cartId.
	 * 
	 * @param cartId
	 */
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	/**
	 * getter method for products.
	 * 
	 * @return products.
	 */
	public List<Product> getProducts() {
		return products;
	}

	/**
	 * setter method for products.
	 * 
	 * @param products
	 */
	public void setProducts(List<Product> products) {
		this.products = products;
	}

	/**
	 * getter method for totalPrice.
	 * 
	 * @return totalPrice.
	 */
	public double getTotalPrice() {
		return totalPrice;
	}

	/**
	 * setter method for totalPrice.
	 * 
	 * @param totalPrice
	 */
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * getter method for user.
	 * 
	 * @return user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * setter method for user.
	 * 
	 * @param user
	 */
	public void setUser(User user) {
		this.user = user;
	}

	
	/**
	 * Default constructor for Cart class.
	 */
	public Cart() {
	}
	
	/**
	 * Parameterized constructor for Cart class.
	 * 
	 * @param cartId
	 * @param productId
	 * @param totalPrice
	 * @param user
	 */
	public Cart(int cartId, List<Product> productId, double totalPrice, User user) {
		super();
		this.cartId = cartId;
		this.products = productId;
		this.totalPrice = totalPrice;
		this.user = user;
	}
	


	/**
	 * hashCode implementation of Cart class.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cartId;
		result = prime * result + ((products == null) ? 0 : products.hashCode());
		long temp;
		temp = Double.doubleToLongBits(totalPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}


	/**
	 * Implementation of equals method for Cart class.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart other = (Cart) obj;
		if (cartId != other.cartId)
			return false;
		if (products == null) {
			if (other.products != null)
				return false;
		} else if (!products.equals(other.products))
			return false;
		if (Double.doubleToLongBits(totalPrice) != Double.doubleToLongBits(other.totalPrice))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}


	/**
	 * Implementation of compareTo method based on cartId.
	 */
	@Override
	public int compareTo(Cart cartObj) {
		if(cartObj == null) {
			return 1;
		}
		if(cartObj.cartId >  cartId) {
			return -1;
		}
		else if(cartObj.cartId < cartId) {
			return 1;
		}
		return 0;
	}
	
}
