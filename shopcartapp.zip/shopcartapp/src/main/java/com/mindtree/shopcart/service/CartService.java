package com.mindtree.shopcart.service;

import java.util.List;

import com.mindtree.shopcart.dto.CartDTO;
import com.mindtree.shopcart.exception.ShoppingCartException;
import com.mindtree.shopcart.model.Product;
import com.mindtree.shopcart.model.User;

public interface CartService {

	/**
	 * Method to add product to cart.
	 * 
	 * @param products
	 * @param userEmail
	 * @param quantity
	 * @return boolean
	 * @throws ShoppingCartException
	 */
	boolean addProductToCart(List<Product> products, User userEmail, int quantity) throws ShoppingCartException;
	
	/**
	 * Method to show details of user cart.
	 * 
	 * @param userEmail
	 * @return
	 * @throws ShoppingCartException
	 */
	CartDTO viewCart(String userEmail) throws ShoppingCartException;
	
	/**
	 * Method to remove a product from cart.
	 * 
	 * @param productId
	 * @param userEmail
	 * @return boolean.
	 * @throws ShoppingCartException
	 */
	boolean removeProductFromCart(int productId, String userEmail) throws ShoppingCartException;
	
	/**
	 * Method to remove all products from cart.
	 * 
	 * @param userEmail
	 * @return boolean
	 * @throws ShoppingCartException
	 */
	boolean removeAllProductsFromCart(String userEmail) throws ShoppingCartException;
}
