package com.mindtree.shopcart.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mindtree.shopcart.model.Product;

@Transactional
public interface ProductDAO extends JpaRepository<Product, Integer>{
	
	List<Product> findByProductName(String productName);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE product set quantity = :quantity where product_id = :productId", nativeQuery=true)
	void updateQuantity(@Param("productId")int productId,@Param("quantity") int quantity);
}
