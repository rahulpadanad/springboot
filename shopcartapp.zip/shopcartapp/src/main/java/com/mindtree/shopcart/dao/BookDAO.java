package com.mindtree.shopcart.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.shopcart.model.Book;

@Transactional
public interface BookDAO extends JpaRepository<Book, Integer>{

}
