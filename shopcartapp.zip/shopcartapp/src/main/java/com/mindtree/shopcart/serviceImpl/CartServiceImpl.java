package com.mindtree.shopcart.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.shopcart.dao.CartDAO;
import com.mindtree.shopcart.dto.CartDTO;
import com.mindtree.shopcart.exception.ShoppingCartException;
import com.mindtree.shopcart.model.Apparel;
import com.mindtree.shopcart.model.Book;
import com.mindtree.shopcart.model.Cart;
import com.mindtree.shopcart.model.Product;
import com.mindtree.shopcart.model.User;
import com.mindtree.shopcart.service.CartService;

@Service
public class CartServiceImpl implements CartService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CartServiceImpl.class);
	
	@Autowired
	private CartDAO cartDao;

	private Map<Integer, Integer> cartProductsMap = new HashMap<Integer, Integer>();

	@Override
	public boolean addProductToCart(List<Product> products, User user, int quantity) throws ShoppingCartException {
		
		LOGGER.info("Adding product to cart");
		
		//double cartTotalAmount = 0.0;
		boolean addedToCart = false;
		
		Cart userCart = cartDao.findCartDetailsByEmail(user.getEmailId());
		
		if (userCart != null && userCart.getCartId() > 0) {
			
			addedToCart = addProductToExistingCart(products, user, quantity, userCart);
			
		} else {
			
			addedToCart = saveNewCartAndAddProducts(products, user, quantity);
		
		}
		
		return addedToCart;
	}

	private boolean addProductToExistingCart(List<Product> products, User user, int quantity, Cart userCart)
			throws ShoppingCartException {
		
		LOGGER.info("User cart already exist. Updating the cart");
		
		double cartTotalAmount = userCart.getTotalPrice();
		List<Product> productsInCart = userCart.getProducts();
		
		updateCartProductMap(productsInCart, quantity);
		
		boolean addedToCart = false;
		try {
			
			for (Product product : products) {
				cartTotalAmount = cartTotalAmount + (product.getProductPrice() * quantity);
				if (!cartProductsMap.containsKey(product.getProductId())) {
					productsInCart.add(product);
				}
			}
			userCart.setProducts(productsInCart);
			userCart.setTotalPrice(cartTotalAmount);
			
			cartDao.save(userCart);
			addedToCart = true;
		} catch (Exception ex) {
			LOGGER.error("Cannot update the cart for user : " + user.getEmailId());
			
			throw new ShoppingCartException("Cannot update the cart for user");
		}
		return addedToCart;
	}

	private boolean saveNewCartAndAddProducts(List<Product> products, User user, int quantity)
			throws ShoppingCartException {
		
		LOGGER.info("addToCart for new User cart");
		
		boolean addedToCart = false;
		double cartTotalAmount = 0.0;
		
		addedToCart = false;
		try {
			
			Cart userCart = new Cart();
			userCart.setProducts(products);
			for (Product product : products) {
				cartTotalAmount = cartTotalAmount + product.getProductPrice();
			}
			userCart.setTotalPrice(cartTotalAmount);
			userCart.setUser(user);
			
			cartDao.save(userCart);
			addedToCart = true;
			updateCartProductMap(products, quantity);
			
		}
		catch (Exception ex) {
			LOGGER.error("Can not save the product in the user cart");
			addedToCart = false;
			throw new ShoppingCartException("Can not save the product in the user cart");
		}
		return addedToCart;
	}

	private void updateCartProductMap(List<Product> products, int quantity) {
		for (Product product : products) {
			if (cartProductsMap != null && !cartProductsMap.containsKey(product.getProductId()))
				cartProductsMap.put(product.getProductId(), quantity);
		}
	}

	@Override
	public CartDTO viewCart(String userEmail) throws ShoppingCartException {
		LOGGER.info("viewCart for user : " + userEmail);
		CartDTO cartDetails = new CartDTO();
		List<Product> products = new ArrayList<Product>();
		Product prodct = null;
		try {
			Cart cart = cartDao.findCartDetailsByEmail(userEmail);
			cartDetails.setUserEmailId(userEmail);
			if (cart != null && cart.getProducts() != null && !cart.getProducts().isEmpty()) {
				for (Product product : cart.getProducts()) {
					if (cartProductsMap.containsKey(product.getProductId())) {
						if (product instanceof Book) {
							prodct = new Book(product.getProductId(), product.getProductName(), product.getProductPrice(),
									cartProductsMap.get(product.getProductId()), ((Book) product).getBookGenre(),
									((Book) product).getBookAuthor(), ((Book) product).getBookPublications());
						} 
						else if (product instanceof Apparel) {
							prodct = new Apparel(product.getProductId(), product.getProductName(), product.getProductPrice(),
									cartProductsMap.get(product.getProductId()), ((Apparel) product).getApparelType(),
									((Apparel) product).getApparelBrand(), ((Apparel) product).getApparelDesign());
						}
						/*
						 * p1.setProductName(p.getProductName());
						 * p1.setQuantity(productMap.get(p.getProductId()));
						 * p1.setProductId(p.getProductId()); p1.setProductPrice(p.getProductPrice());
						 */

						products.add(prodct);
					}
				}
				cartDetails.setProducts(products);
				cartDetails.setCartAmount(cart.getTotalPrice());
			}
		} catch (Exception ex) {
			LOGGER.error("Cart does not exist for user : " + userEmail);
			throw new ShoppingCartException("Cannot find the cart for user details");
		}
		return cartDetails;
	}

	@Override
	public boolean removeProductFromCart(int productId, String userEmail) throws ShoppingCartException {
		LOGGER.info("removing Product from cart");
		boolean successfullyRemoved = false;
		try {
			//int i = 0;
			Cart cart = cartDao.findCartDetailsByEmail(userEmail);
			if (cart != null && cart.getProducts() != null) {
				Iterator<Product> productIterator = cart.getProducts().iterator();
				while(productIterator.hasNext()) {
					Product product = productIterator.next();
					if (product.getProductId() == productId) {
						productIterator.remove();
						break;
					}
				}
				/*for (Product product : cart.getProducts()) {
					if (product.getProductId() == productId) {
						cart.getProducts().remove(i);
						break;
					}
					i++;
				}*/
				cartDao.saveAndFlush(cart);
				successfullyRemoved = true;
				if (cartProductsMap != null && cartProductsMap.containsKey(productId)) {
					cartProductsMap.remove(productId);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("User cart cannot be found for user: " + userEmail);
			throw new ShoppingCartException("User cart cannot be found");
		}
		return successfullyRemoved;
	}

	@Override
	public boolean removeAllProductsFromCart(String userEmail) throws ShoppingCartException {
		LOGGER.info("INFO : removeAllProductsFromCart for user : " + userEmail);
		List<Product> products = new ArrayList<Product>();
		boolean successfullyRemoved = false;
		try {
			Cart cart = cartDao.findCartDetailsByEmail(userEmail);
			if (cart != null && cart.getProducts() != null && !cart.getProducts().isEmpty()) {
				products = cart.getProducts();
				cart.getProducts().removeAll(cart.getProducts());
			}
			
			cartDao.saveAndFlush(cart);
			
			successfullyRemoved = true;
			
			for (Product product : products) {
				if (cartProductsMap != null && cartProductsMap.containsKey(product.getProductId())) {
					cartProductsMap.remove(product.getProductId());
				}
			}
		} catch (Exception ex) {
			LOGGER.error("ERROR : Products can not be deleted from the cart for user : " + userEmail);
			throw new ShoppingCartException("Products can not be deleted from the cart");
		}
		
		return successfullyRemoved;
	}
}
